
package main_try;

import java.sql.* ;
import javax.swing.* ;
import java.awt.* ;
import java.awt.event.* ;
import java.util.* ;
//Main_try is main menu
class Main_try extends JFrame implements ActionListener{  // This class provides the first PAGE 

		JButton jb1, jb2, jb3, jb4 ;

		public Main_try(){

		super("Main Menu") ;
		setSize(500, 500) ;
 
		setLayout(new BorderLayout()) ;
		JLabel background = new JLabel(new ImageIcon(getClass().getResource("/images/black_white.jpg"))) ;
		add(background) ;

		background.setLayout(new BoxLayout(background,BoxLayout.Y_AXIS)) ;

		JLabel label = new JLabel("Dodge Me!!!!") ;
		label.setForeground(Color.black) ;
		label.setFont(new Font("Serif", Font.ITALIC|Font.BOLD, 50)) ;
		
		 jb1 = new JButton("        Play       " ) ;
		jb1.addActionListener(this) ;

		jb2 = new JButton(" Instruction  ") ;
		jb2.addActionListener(this) ;

		 jb3 = new JButton(" Highscores ") ;
		jb3.addActionListener(this) ;

		jb4 = new JButton("         Exit        ") ;
		jb4.addActionListener(this) ;

		background.add(Box.createVerticalStrut(50)) ;

		label.setAlignmentX(JComponent.CENTER_ALIGNMENT) ;   // This is used to align the components towards the center
		background.add(label) ;
		background.add(Box.createVerticalStrut(50)) ;

		jb1.setAlignmentX(JComponent.CENTER_ALIGNMENT) ;
		background.add(jb1) ;
		background.add(Box.createVerticalStrut(10)) ;

		jb2.setAlignmentX(JComponent.CENTER_ALIGNMENT) ;
		background.add(jb2) ;
		background.add(Box.createVerticalStrut(10)) ;

		jb3.setAlignmentX(JComponent.CENTER_ALIGNMENT) ;
		background.add(jb3) ;
		background.add(Box.createVerticalStrut(10)) ;

		jb4.setAlignmentX(JComponent.CENTER_ALIGNMENT) ;
		background.add(jb4) ;
		background.add(Box.createVerticalStrut(10)) ;
	}

                @Override
	public void actionPerformed(ActionEvent ae)
	{
		JButton button = (JButton) ae.getSource() ;

		if( button == jb1 )   // This method takes the frame containing customization properties
		{
			setVisible(false) ;
			Customize cn = new Customize() ;
		}

		else if( button == jb2 )    // This method take the frame containing Instructions
		{
			setVisible(false) ;
			Instructions in = new Instructions() ;
		}

		else if( button == jb3 ) // This method takes us to the frame containing Highscores
		{
                    setVisible(false) ;
                    Highscore hi = new Highscore() ;
		}

		else if( button == jb4 ) // Exit from the game
		{
			System.exit(0) ;
		}
	}

	public static void main( String args[] )
	{
		Main_try ob = new Main_try() ;
		ob.setLocationRelativeTo(null) ;
		ob.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE) ;
		ob.setVisible(true) ;
	}
}

class Instructions extends JFrame implements ActionListener{

	JButton back, play ;

	// This constructor is used as the dummy constructor to call function changePath
	public Instructions() 
	{
		changePath() ;
	}

	// This constructor is used as the function which will initialze the frame and call the constuctor which is required to us
	public void changePath() 
	{
		Instructions in = new Instructions(1) ;
		in.setLocationRelativeTo(null) ;
		in.setVisible(true) ;
		in.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE) ;
	}

	public Instructions(int i)
	{
		super("Instruction") ;
		setSize(723, 610) ;
		setLayout(new BorderLayout()) ;

		JLabel ins = new JLabel(new ImageIcon(getClass().getResource("/images/Instruction1.jpg"))) ;
		add(ins) ;

		ins.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5)) ;

		back = new JButton("Back") ;
		back.addActionListener(this) ;
		ins.add(back) ;

		play = new JButton("Play") ;
		play.addActionListener(this) ;
		ins.add(play) ;
	}

	public void actionPerformed(ActionEvent ae)
	{
		JButton ch = (JButton) ae.getSource() ;

		// This will take us back to the main menu
		if( ch == back ) 
		{
			setVisible(false) ;
			Main_try reapear = new Main_try() ;
			reapear.setVisible(true) ;
			reapear.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE) ;
			reapear.setLocationRelativeTo(null) ;
		}
		// This will take us to the customization page
		else if( ch == play )
		{
			setVisible(false) ;
			Customize co = new Customize() ;
		}
	}
}

class Customize extends JFrame {

		public int red = 50, green = 50, blue = 50 ;
		JButton jb1, jb2, jb3 ;
		JLabel lb1, lb2, lb3, background ;
		Scrollbar sb1, sb2, sb3 ;
		Canvas canvas ;

		public Customize()
		{
			setPath() ;	
		}

		public void setPath() 
		{
			Customize ob = new Customize(1) ;
			ob.setSize(500, 500) ;
			ob.setLocationRelativeTo(null) ;
			ob.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE) ;	
			ob.setVisible(true) ;
		}

		public Customize(int i)
		{
			super("Customize") ;

			JTabbedPane jtp = new JTabbedPane() ;
			jtp.add("Set Background",new Set_Background()) ;
			jtp.add("Level",new Level()) ;
			add(jtp) ;
		}

		public void close_frame()
		{
			setVisible(false) ;
		}

		class Set_Background extends JPanel implements AdjustmentListener, ActionListener{

			int difficulty = 7 ;

			Set_Background()
			{
				setLayout(new BorderLayout()) ;
				background = new JLabel(new ImageIcon(getClass().getResource("/images/black_white.jpg"))) ;
				add(background) ;

				canvas = new Canvas() ;
				canvas.setSize(30, 30) ;
				canvas.setBackground(Color.white) ;

				background.setLayout(new FlowLayout(FlowLayout.CENTER, 15, 150)) ;
				
				lb1 = new JLabel("RED") ;
				lb1.setForeground(Color.red) ;
				sb1 = new Scrollbar(Scrollbar.HORIZONTAL, 50, 5, 0, 255) ;
				sb1.addAdjustmentListener(this) ;
				background.add(lb1) ;
				background.add(sb1) ;

				background.add(Box.createVerticalStrut(10)) ;
				lb2 = new JLabel("GREEN") ;
				lb2.setForeground(Color.green) ;
				sb2 = new Scrollbar(Scrollbar.HORIZONTAL, 50, 5, 0, 255) ;
				sb2.addAdjustmentListener(this) ;
				background.add(lb2) ;
				background.add(sb2) ;

				background.add(Box.createVerticalStrut(10)) ;
				lb3 = new JLabel("BLUE") ;
				lb3.setForeground(Color.blue) ;
				sb3 = new Scrollbar(Scrollbar.HORIZONTAL, 50, 5, 0, 255) ;
				sb3.addAdjustmentListener(this) ;
				background.add(lb3) ;
				background.add(sb3) ;

				background.add(canvas) ;

				jb1 = new JButton("Back") ;
				jb1.addActionListener(this) ;
				background.add(jb1) ;

				jb2 = new JButton("Skip") ;
				background.add(jb2) ;
				jb2.addActionListener(this) ;
			}


			public void adjustmentValueChanged(AdjustmentEvent ae)
			{
				 red = (int) sb1.getValue() ;
				 green = (int) sb2.getValue() ;
				 blue = (int) sb3.getValue() ;

				 Color color = new Color(red, green, blue) ;
				 canvas.repaint() ;
   				 canvas.setBackground(color) ;

			}

			public void actionPerformed(ActionEvent ae)
			{
				String str = ae.getActionCommand() ;

				if( str == "Back" )  // This is used to go back to the main menu
				{
					close_frame() ;
					Main_try reapear = new Main_try() ;
					reapear.setVisible(true) ;
					reapear.setLocationRelativeTo(null) ;
					reapear.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE) ;
				}
				else if( str == "Skip" ) 
				{
					close_frame() ;

					Game gm = new Game(50,60,40,200,300,200,300,200,300,250,300,200,300,200,500,difficulty) ;
				}
			}
		}

		class Level extends JPanel implements ItemListener, ActionListener{

			JComboBox jc ;
			int difficulty = 7 ;

			Level()
			{
				setLayout(new BorderLayout()) ;

				background = new JLabel(new ImageIcon(getClass().getResource("/images/black_white.jpg"))) ;
				add(background) ;

				// We are adding componenets on the background 

				background.setLayout(new FlowLayout(FlowLayout.CENTER, 15, 150)) ;

				jc = new JComboBox() ;
				jc.addItem("Easy") ;
				jc.addItem("Medium") ;
				jc.addItem("Tough") ;
				background.add(jc) ;
				jc.addItemListener(this) ;

				// The space has been allocated to but the button in the next row

				lb1 = new JLabel("Select the difficulty level you wish to start with.                   ") ;
				lb1.setForeground(Color.black) ;
				background.add(lb1) ;

				jb1 = new JButton("Back") ;
				jb1.addActionListener(this) ;
				background.add(jb1) ;

				jb2 = new JButton("I am ready!") ;
				jb2.addActionListener(this) ;
				background.add(jb2) ;

				jb3 = new JButton("Skip") ;
				jb3.addActionListener(this) ;
				background.add(jb3) ;
			}

			public void itemStateChanged(ItemEvent ie)
			{

				if( ie.getItem() == "Easy" )
				{
					lb1.setText(" You have selected easy as the difficulty of the game.             " ) ;
					difficulty = 10 ;
				}
				else if( ie.getItem() == "Medium" )
				{
					lb1.setText(" You have selected Medium as the difficulty of the game.         " ) ;
					difficulty = 7 ;
				}
				else if( ie.getItem() == "Tough")
				{
					lb1.setText(" You hava selected Tough as the difficulty of the game.          ");
					difficulty = 5 ;
				}
			}	

			public void actionPerformed(ActionEvent ae)
			{
				JButton b = (JButton) ae.getSource() ;

				if( b == jb1 ) // This is used to go back to the main menu
				{
					close_frame() ;
					Main_try cn = new Main_try() ;
					cn.setVisible(true) ;
					cn.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE) ;
					cn.setLocationRelativeTo(null) ;
				}
				else if( b == jb2 ) // This is used to start the game
				{
					close_frame() ;

					Game gm = new Game(red ,green ,blue ,200,350,200,300,200,300,250,330,200,300,200,500,difficulty) ;
				}
				else if( b == jb3 ) // This will take the default values and start the game
				{
					close_frame() ;

                                //  Game gm = new Game(red, green, blue, xc, yc, xc1, yc1, xc2, yc2, xc3, yc3, xc4, yc4, xc5, yc5, difficulty) 
					Game gm = new Game(50,60,40,200,300,200,300,200,300,250,300,200,300,200,500,7) ;
				}
		}
	}		
}

class Game extends JFrame {

	int xc, yc ;
	int xc1, yc1 ;
	int xc2 , yc2 ;
	int xc3 , yc3 ;
	int xc4 , yc4 ;
	int xc5 , yc5 ;
	public int r1,g1,b1 ;
	int difficulty ;

	Game(int r,int g,int b,int xc,int yc,int xc1,int yc1,int xc2,int yc2,int xc3,int yc3,int xc4,int yc4,int xc5,int yc5,int difficulty)
	{
		this.difficulty = difficulty ;
		this.xc = xc ;	this.xc1 = xc1 ; this.xc2 = xc2 ; this.xc3 = xc3 ; this.xc4 = xc4 ; this.xc5 = xc5 ;
		this.yc = yc ;  this.yc1 = yc1 ; this.yc2 = yc2 ; this.yc3 = yc3 ; this.yc4 = yc4 ; this.yc5 = yc5 ;
		r1 = r ; g1 = g ; b1 = b ;
		changePath(r1,g1,b1) ;
	}

	public void changePath(int r1, int g1, int b1)
	{
		Game gm = new Game(1, r1, g1, b1, xc, yc,xc1,yc1,xc2,yc2,xc3,yc3,xc4,yc4,xc5,yc5,difficulty) ;
		gm.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE) ;
		gm.setLocationRelativeTo(null) ;
	}

	Game(int i, int r1, int g1, int b1, int xc , int yc,int xc1,int yc1,int xc2,int yc2,int xc3,int yc3,int xc4,int yc4,int xc5,int yc5,int difficulty)
	{
		setTitle("Dodge Me!!!") ;		
		setVisible(true) ;
		add(new Obstacles(r1,g1,b1,xc,yc,xc1,yc1,xc2,yc2,xc3,yc3,xc4,yc4,xc5,yc5,difficulty)) ;
		setSize(1200, 700) ;
	}  

	public void close_frame()
	{
		setVisible(false) ;
	}

	class Obstacles extends JPanel implements Runnable, MouseMotionListener, MouseListener{

		Thread t ;
		int mouseX , mouseY ;
		int diff = 1000;
		int beyound_the_boundry = 0 ;
		int life_bar = 540 ;
		int choice = 4;
		int mul1 = 1 , mul = 1 ;
		int mul1_2 = 1 , mul_2 = 1 ;
		int mul1_3 = 1 , mul_3 = 1 ;
		int mul1_4 = 1 , mul_4 = 1 ;
		int mul1_5 = 1 , mul_5 = 1 ;
		int mul1_6 = 1 , mul_6 = 1 ;
		int reached = 9 ;
		int bonusX1 = 350 , bonusX2 = 400 , bonusX3 = 500 , bonusX4 = 700 , bonusX5 = 900 ;
		int bonusY1 = 300 , bonusY2 = 500 , bonusY3 = 400 , bonusY4 = 350 , bonusY5 = 450 ;
		int bonus_counter = 0 ;
		int min = 0 , sec = 0 , milsec = 0 ;
		double radians, radians1 , radians2 ,radians3, radians4 , radians5 ;
		int xc, yc ,xc1 , yc1, xc2, yc2, xc3, yc3, xc4, yc4, xc5, yc5;
		int rr, gg, bb;
		int visible = 1 ;     // To give only one bonus at a time
		int present1 = 0 , present2 = 0 , present3 = 0 , present4 = 0 , present5 = 0 ; // To check the obstacle present on the screen wether it has been taken or not
                int z1, z12, z2, z22, z3, z32, z4, z42 , z5, z52;

		Obstacles(int r1, int g1, int b1, int xc ,int yc,int xc1,int yc1,int xc2,int yc2,int xc3,int yc3,int xc4,int yc4,int xc5,int yc5,int difficulty)
		{
			rr=r1; gg=g1; bb=b1;

			diff = difficulty ;
	
			this.xc = xc ; this.xc1 = xc1 ; this.xc2 = xc2 ; this.xc3 = xc3 ; this.xc4 = xc4 ; this.xc5 = xc5 ;
			this.yc = yc ; this.yc1 = yc1 ; this.yc2 = yc2 ; this.yc3 = yc3 ; this.yc4 = yc4 ; this.yc5 = yc5 ;

			addMouseMotionListener(this) ;
                        
                   
                        

			create_custom_cursor() ;
			t = new Thread(this) ;
			t.start() ;
		}

		public void create_custom_cursor()
		{
			Toolkit toolkit = Toolkit.getDefaultToolkit() ; 
			Image img = toolkit.getImage(getClass().getResource("/images/Stick.png")) ;
			Point point = new Point(0,0) ;
			toolkit.getBestCursorSize(30,30) ;
			Cursor cursor = toolkit.createCustomCursor(img,point,"Stick") ;
			toolkit.getBestCursorSize(10,10) ;
			setCursor(cursor) ;
		}

		public void run()
		{
			try{
                            // It is the timer function 
				while(true){
					Thread.sleep(diff) ;
				milsec++ ;
			if( milsec == 100 )
			{
				sec++ ;
				milsec = 0 ;
				if( sec == 60 )
				{
					sec = 0 ;
					min++ ;
				}
			}
					repaint() ;
				}
			}catch(InterruptedException e)
			{
				e.printStackTrace() ;
			}
		}

		public void paintComponent( Graphics g )
		{
			

			super.paintComponent(g) ;
                        
                             Random cord = new Random() ;
                             // These produce random values w
                        z1 = (cord.nextInt(3)) ; z12 = (cord.nextInt(3)) ;
                        z2 = (cord.nextInt(3)) ; z22 = (cord.nextInt(3)) ;
                        z3 = (cord.nextInt(3)) ; z32 = (cord.nextInt(3)) ;
                        z4 = (cord.nextInt(3)) ; z42 = (cord.nextInt(3)) ;
                        z5 = (cord.nextInt(3)) ; z52 = (cord.nextInt(3)) ;

			lifeBar(g,0) ;

			Font font = new Font("Serif",Font.BOLD|Font.ITALIC,30) ;
			g.setFont(font) ;
			g.drawString(""+min +":"+sec+":"+milsec,50,50) ;

			g.setColor(Color.black);
			g.drawLine(0,90,1200,90) ;
			g.drawLine(0,93,1200,93) ;

			int x , y ;
			int x1 = 0 , y1 = 0 , x2 = 0 , y2 = 0 ;
 			int r = 90 ;
			
			r1 = rr;
			g1 = gg;
			b1 = bb;

			Color color = new Color(r1,g1,b1) ;
			setBackground(color) ;

			if( color == Color.white ) 
				g.setColor(Color.black) ;
			else
				g.setColor(Color.white) ;

                        // From here it creates the obstacles for the game
			/* ------------------- 1St Obstacle -----------------------------*/ 
			
			// 1st Arm 
                        
			x = xc + (int)(r * Math.cos(radians)) ;
			y = yc - (int)(r * Math.sin(radians)) ;

			g.drawLine(xc, yc, x, y) ;
			x2 = x1 = x ; y2 = y1 = y ;

			// 2nd Arm
			x = xc + (int)(r * Math.cos(radians + Math.PI/2)) ;
			y = yc - (int)(r * Math.sin(radians + Math.PI/2)) ;

			g.drawLine(xc, yc, x, y) ;
			g.drawLine(x, y, x1, y1) ;
			x1 = x ; y1 = y ;

			// 3rd Arm
			x = xc + (int)(r * Math.cos(radians + Math.PI)) ;
			y = yc - (int)(r * Math.sin(radians + Math.PI)) ;

			g.drawLine(xc ,yc ,x ,y) ;
			g.drawLine(x, y, x1, y1) ;
			x1 = x ; y1 = y ;

			//4th Arm
			x = xc + (int)(r * Math.cos(radians + 1.5*Math.PI)) ;
			y = yc - (int)(r * Math.sin(radians + 1.5*Math.PI)) ;

			g.drawLine(x, y, xc, yc) ;
			g.drawLine(x, y, x1, y1) ;
			g.drawLine(x2, y2, x, y) ;

			// To rotate 

			radians += Math.PI/180 ;
			xc += (mul)*(int)z1 ;
			yc -= (mul1)*(int)z12 ;

			if( (yc+100) >= 700 || (yc-100) <= 100 )
			{
				mul1*= -1 ;
			}

			if( (xc+100) >= 1200 || ( xc-100) <= 0 )
			{
				mul *= -1 ;
			}

			/* -------------------------------- 2nd Obstacle ----------------------------------- */
			
				// 1st Arm 
			x = xc1 + (int)(r * Math.cos(radians1)) ;
			y = yc1 - (int)(r * Math.sin(radians1)) ;

			g.drawLine(xc1, yc1, x, y) ;
			x2 = x1 = x ; y2 = y1 = y ;

			// 2nd Arm
			x = xc1 + (int)(r * Math.cos(radians1 + Math.PI/2)) ;
			y = yc1 - (int)(r * Math.sin(radians1 + Math.PI/2)) ;

			g.drawLine(xc1, yc1, x, y) ;
			g.drawLine(x, y, x1, y1) ;
			x1 = x ; y1 = y ;

			// 3rd Arm
			x = xc1 + (int)(r * Math.cos(radians1 + Math.PI)) ;
			y = yc1 - (int)(r * Math.sin(radians1 + Math.PI)) ;

			g.drawLine(xc1 ,yc1 ,x ,y) ;
			g.drawLine(x, y, x1, y1) ;
			x1 = x ; y1 = y ;

			//4th Arm
			x = xc1 + (int)(r * Math.cos(radians1 + 1.5*Math.PI)) ;
			y = yc1 - (int)(r * Math.sin(radians1 + 1.5*Math.PI)) ;

			g.drawLine(x, y, xc1, yc1) ;
			g.drawLine(x, y, x1, y1) ;
			g.drawLine(x2, y2, x, y) ;

			// To rotate 

			radians1 += Math.PI/180 ;
			xc1 += (mul_2)*(int)z2 ;
			yc1 += (mul1_2)*(int)z22 ;

			if( (yc1+100) >= 700 || (yc1-100) <= 100 )
			{
				mul1_2*= -1 ;
			}

			if( (xc1+120) >= 1200 || (xc1 - 100) <= 0 )
			{
				mul_2 *= -1 ;
			}
			/* -------------------------------- 3rd Obstacle ----------------------------------- */
			
				// 1st Arm 
			x = xc2 + (int)(r * Math.cos(radians2)) ;
			y = yc2 - (int)(r * Math.sin(radians2)) ;

			g.drawLine(xc2, yc2, x, y) ;
			x2 = x1 = x ; y2 = y1 = y ;

			// 2nd Arm
			x = xc2 + (int)(r * Math.cos(radians2 + Math.PI/2)) ;
			y = yc2 - (int)(r * Math.sin(radians2 + Math.PI/2)) ;

			g.drawLine(xc2, yc2, x, y) ;
			g.drawLine(x, y, x1, y1) ;
			x1 = x ; y1 = y ;

			// 3rd Arm
			x = xc2 + (int)(r * Math.cos(radians2 + Math.PI)) ;
			y = yc2 - (int)(r * Math.sin(radians2 + Math.PI)) ;

			g.drawLine(xc2 ,yc2 ,x ,y) ;
			g.drawLine(x, y, x1, y1) ;
			x1 = x ; y1 = y ;

			//4th Arm
			x = xc2 + (int)(r * Math.cos(radians2 + 1.5*Math.PI)) ;
			y = yc2 - (int)(r * Math.sin(radians2 + 1.5*Math.PI)) ;

			g.drawLine(x, y, xc2, yc2) ;
			g.drawLine(x, y, x1, y1) ;
			g.drawLine(x2, y2, x, y) ;

			// To rotate 

			radians2 += Math.PI/180 ;
			xc2 -= (mul_3)*(int)z3 ;
			yc2 -= (mul1_3)*(int)z32 ;

			if( (yc2+100) >= 700 || (yc2-100) <= 100 )
			{
				mul1_3*= -1 ;
			}

			if( (xc2+100) >= 1200 || (xc2 - 100) <= 0 )
			{
				mul_3 *= -1 ;
			}


			/* -------------------------------- 4th Obstacle ----------------------------------- */
			
				// 1st Arm 
			x = xc4 + (int)(r * Math.cos(radians4)) ;
			y = yc4 - (int)(r * Math.sin(radians4)) ;

			g.drawLine(xc4, yc4, x, y) ;
			x2 = x1 = x ; y2 = y1 = y ;

			// 2nd Arm
			x = xc4 + (int)(r * Math.cos(radians4 + Math.PI/2)) ;
			y = yc4 - (int)(r * Math.sin(radians4 + Math.PI/2)) ;

			g.drawLine(xc4, yc4, x, y) ;
			g.drawLine(x, y, x1, y1) ;
			x1 = x ; y1 = y ;

			// 3rd Arm
			x = xc4 + (int)(r * Math.cos(radians4 + Math.PI)) ;
			y = yc4 - (int)(r * Math.sin(radians4 + Math.PI)) ;

			g.drawLine(xc4 ,yc4 ,x ,y) ;
			g.drawLine(x, y, x1, y1) ;
			x1 = x ; y1 = y ;

			//4th Arm
			x = xc4 + (int)(r * Math.cos(radians4 + 1.5*Math.PI)) ;
			y = yc4 - (int)(r * Math.sin(radians4 + 1.5*Math.PI)) ;

			g.drawLine(x, y, xc4, yc4) ;
			g.drawLine(x, y, x1, y1) ;
			g.drawLine(x2, y2, x, y) ;

			// To rotate 

			radians4 += Math.PI/180 ;
			xc4 -= (mul_5)*(int)z4 ;
			yc4 += (mul1_5)*(int)z42 ;

			if( (yc4+100) >= 700 || (yc4-100) <= 100 )
			{
				mul1_5*= -1 ;
			}

			if( (xc4+100) >= 1200 || (xc4-100) <= 0 )
			{
				mul_5 *= -1 ;
			}


			/* -------------------------------- 5th Obstacle ----------------------------------- */
			
				// 1st Arm 
			x = xc5 + (int)(r * Math.cos(radians5)) ;
			y = yc5 - (int)(r * Math.sin(radians5)) ;

			g.drawLine(xc5, yc5, x, y) ;
			x2 = x1 = x ; y2 = y1 = y ;

			// 2nd Arm
			x = xc5 + (int)(r * Math.cos(radians5 + Math.PI/2)) ;
			y = yc5 - (int)(r * Math.sin(radians5 + Math.PI/2)) ;

			g.drawLine(xc5, yc5, x, y) ;
			g.drawLine(x, y, x1, y1) ;
			x1 = x ; y1 = y ;

			// 3rd Arm
			x = xc5 + (int)(r * Math.cos(radians5 + Math.PI)) ;
			y = yc5 - (int)(r * Math.sin(radians5 + Math.PI)) ;

			g.drawLine(xc5 ,yc5 ,x ,y) ;
			g.drawLine(x, y, x1, y1) ;
			x1 = x ; y1 = y ;

			//4th Arm
			x = xc5 + (int)(r * Math.cos(radians5 + 1.5*Math.PI)) ;
			y = yc5 - (int)(r * Math.sin(radians5 + 1.5*Math.PI)) ;

			g.drawLine(x, y, xc5, yc5) ;
			g.drawLine(x, y, x1, y1) ;
			g.drawLine(x2, y2, x, y) ;

			// To rotate 

			radians5 += Math.PI/180 ;
			xc5 += (mul_6)*(int)z5 ;
			yc5 += (mul1_6)*(int)z52 ;

			if( (yc5+120) >= 700 || (yc5-120) <= 100 )
			{
				mul1_6 *= -1 ;
			} 

			if( (xc5+120) >= 1200 || (xc5-120) <= 0 )
			{
				mul_6 *= -1 ;
			} //*/

			check() ;

			if( life_bar < 150  )
			bonus(g) ;

			if( life_bar <= 0 )
			{
				close_frame() ;
				Haunt obj = new Haunt() ;
				obj.haunt_create_frame(min,sec,milsec) ;
			}
		}

		public void mouseMoved(MouseEvent me)
		{
			 mouseX = me.getX() ;
			 mouseY = me.getY() ;  
		}

		public void mouseDragged(MouseEvent me){}
		
		public void mouseClicked(MouseEvent me){}
		public void mousePressed(MouseEvent me){}
		public void mouseReleased(MouseEvent me){}

		public void mouseEntered(MouseEvent me){
			beyound_the_boundry = 0 ;
		}

		public void mouseExited(MouseEvent me){
			beyound_the_boundry = 1 ;
		}

                // This function enables the life bar 
		public void lifeBar(Graphics g,int lifebar)
		{
			g.setColor(Color.white) ;
			g.fillRect(600,30,550,30) ;

			if( life_bar >= 300 )
			g.setColor(Color.green) ;
			else if( life_bar >= 150 )
			g.setColor(Color.yellow) ;
			else if( life_bar < 150 )
			g.setColor(Color.red) ;

			g.fillRect(605,33,life_bar,24) ;

			if( beyound_the_boundry == 1 )
			{
				if( life_bar == 0 )
					life_bar = 0 ;
				else
					life_bar-- ;
			}
		}

		public void check()
		{
                    // All the below if else checks wether the protagonist has made contact with the bonuses
			if(mouseX+3 >= bonusX1 && (bonusX1+25) >= mouseX-3 && mouseY-3 >= bonusY1 && (bonusY1+25) >= mouseY-3 && present1 == 1)	
			{
				visible = 1 ;
				present1 = 0 ;
				bonus_counter++ ;
				life_bar += 50 ;
			}

			else if(mouseX+3 >= bonusX2 && (bonusX2+25) >= mouseX-3 && mouseY-3 >= bonusY2 && (bonusY2+25) >= mouseY-3 && present2 == 1)	
			{
				visible = 1 ;
				present2 = 0 ;
				bonus_counter++ ;
				life_bar += 50 ;
			}

			else if(mouseX+3 >= bonusX3 && (bonusX3+25) >= mouseX-3 && mouseY+3 >= bonusY3 && (bonusY3+25) >= mouseY-3 && present3 == 1)	
			{
				visible = 1 ;
				present3 = 0 ;
				bonus_counter++ ;
				life_bar += 50 ;
			}

			else if(mouseX+3 >= bonusX4 && (bonusX4+25) >= mouseX-3 && mouseY+3 >= bonusY4 && (bonusY4+25) >= mouseY-3 && present4 == 1)	
			{
				visible = 1 ;
				present4 = 0 ;
				bonus_counter++ ;
				life_bar += 50 ;
			}

			else if(mouseX+3 >= bonusX5 && (bonusX5+25) >= mouseX-3 && mouseY+3 >= bonusY5 && (bonusY5+25) >= mouseY-3 && present5 == 1)	
			{
				visible = 1 ;
				present5 = 0 ;
				bonus_counter++ ;
				life_bar += 50 ;
			}

                        
                        // All the bellow if else statements checks wether the protagonist has made contact with the obstacles
			if( (mouseX-3) <= xc+90 && (mouseX+3) >= xc-90 && (mouseY-3) <= yc+90 && (mouseY+3) >= yc-90 )
			{
				life_bar -= 10 ;
			}

			else if( (mouseX-3) <= xc1+90 && (mouseX+3) >= xc1-90 && (mouseY-3) <= yc1+90 && (mouseY+3) >= yc1-90 )
			{
				life_bar -= 10 ;
			}

			else if( (mouseX-3) <= xc2+90 && (mouseX+3) >= xc2-90 && (mouseY-3) <= yc2+90 && (mouseY+3) >= yc2-90 ) 
			{
				life_bar -= 10 ;
			}

			else if( (mouseX-3) <= xc4+90 && (mouseX+3) >= xc4-90 && (mouseY-3) <= yc4+90 && (mouseY+3) >= yc4-90 )
			{
				life_bar -= 10 ;
			}

			else if( (mouseX-3) <= xc5+90 && (mouseX+3) >= xc5-90 && (mouseY-3) <= yc5+90 && (mouseY+3) >= yc5-90 )
			{
				life_bar -= 10 ;
			}

			if( mouseY < 90 )
			{
				beyound_the_boundry = 1 ;
			}
			else 
				beyound_the_boundry = 0 ;
                        
                        
                }

                // This function gives the bonuses in the game
		public void bonus(Graphics g)
		{
			Random rand = new Random() ;
			if( visible == 1 )                  // If the visible flag varaible is set then only it will dispaly the bonus
			{
				choice = (int)(rand.nextInt(10)) ;
				visible = 0 ;
			}
			
			g.setColor(Color.magenta) ;
			if( choice <= 2 )			
			{
				g.fillOval(bonusX1,bonusY1,25,25) ;
				present1 = 1 ;
			}
			else if( choice > 2 && choice <= 4 )
			{     
				g.fillOval(bonusX2,bonusY2,25,25) ;
				present2 = 1 ;
			}
			else if( choice > 4 && choice <= 6 )
			{
				g.fillOval(bonusX3,bonusY3,25,25) ;
				present3 = 1 ;
			}
			else if( choice > 6 && choice <= 8 )
			{
				g.fillOval(bonusX4,bonusY4,25,25) ;
				present4 = 1 ;
			}
			else if(choice > 8 && choice < 10 )
			{
				g.fillOval(bonusX5,bonusY5,25,25) ;
				present5 = 1 ;
			} 
	}

	}
}

//This class prompts the user wether he/she would want to save highscores
class Save_To_Highscores extends JFrame implements ActionListener{   //<< Persistent >>

	JLabel background, timing, name ;
	JTextField name_enter ;
	int min1, sec1, milsec1, timer ;
	JButton main_menu, save ;
        String t ;
        

	Save_To_Highscores(int min, int sec, int milsec)
	{
		min1 = min ;
		sec1 = sec ;
		milsec1 = milsec ;
		changePath() ;
	}

	public void changePath()
	{
		Save_To_Highscores save = new Save_To_Highscores(1,min1,sec1,milsec1) ;
		save.setVisible(true) ;
		save.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE) ;
		save.setLocationRelativeTo(null) ;
	}

	public void close_frame()
	{
		setVisible(false) ;
	}

	public Save_To_Highscores(int i,int m,int s,int mil)
	{
		super("Sub Menu") ;
               
		setSize(500,300) ;
		setLayout(new BorderLayout()) ;
		background = new JLabel(new ImageIcon(getClass().getResource("/images/black_white.jpg"))) ;
		add(background) ;
		background.setLayout(new FlowLayout(FlowLayout.CENTER,10,50)) ;
                
                // The conversion which is required to store in the database 
                t = ""+m+":"+s+":"+mil ;
                timer = (m*60*1000) + (s*1000) + mil ;
		
		name = new JLabel("Name                     ") ;
		name.setForeground(Color.black) ;
		background.add(name) ;
		
		name_enter = new JTextField(15) ;
		background.add(name_enter) ; 
		
		timing = new JLabel("                                                    Your timing:" +m +":" +s +":"  +mil +"                                                     ") ;
		timing.setForeground(Color.black) ;
		background.add(timing) ;
		
		main_menu = new JButton("Main Menu") ;
		main_menu.addActionListener(this) ;
		background.add(main_menu) ;

		save = new JButton("Save Score");
		save.addActionListener(this) ;
		background.add(save) ;
	}

	public void actionPerformed(ActionEvent ae)
	{
		JButton button = (JButton) ae.getSource() ;

		if( button == main_menu )
		{
			close_frame() ;
			Main_try obj = new Main_try() ;
			obj.setVisible(true) ;
			obj.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE) ;
			obj.setLocationRelativeTo(null) ;
		}

		else if( button == save )
		{
                    String nam = (String)name_enter.getText() ;
                           try{
     
                            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/dodge_me","root","forgotpass1") ;
                            
                            Statement stm = con.createStatement() ;
                         
                           String sql = "insert into highscore values (NULL,'"+nam +"','" +t +"'," +timer +")";
                            
                            stm.executeUpdate(sql) ;
                            
                       	close_frame() ;
			Main_try obj = new Main_try() ;
			obj.setVisible(true) ;
			obj.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE) ;
			obj.setLocationRelativeTo(null) ;
		
                            
                           }catch(Exception e)
                            {
                                e.printStackTrace() ;
                            }
		}
	}
}


// This class displays the error message which indicates that the game is over
class Haunt extends JFrame implements ActionListener{

	JButton next ;
	int min, sec, milsec ;
	int m1 , s1 , mil1 ;

	Haunt()
	{}

	public void haunt_create_frame(int min, int sec, int milsec)
	{
		this.min = min ; this.sec = sec ; this.milsec = milsec ;
		Haunt obj = new Haunt(min,sec,milsec) ;
		obj.setSize(500,500) ;
		obj.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE) ;
		obj.setLocationRelativeTo(null) ;
	}

	public void close_frame()
	{
		setVisible(false) ;
	}

	public Haunt(int min, int sec, int milsec)
	{
		super("Game Over") ;

		m1 = min ; s1 = sec ; mil1 = milsec ;

		setVisible(true) ;

		setLayout(new BorderLayout()) ;

		JLabel background = new JLabel(new ImageIcon(getClass().getResource("/images/blood.png"))) ;

		add(background) ;

		background.setLayout(new FlowLayout(FlowLayout.CENTER,50,400)) ;

		next = new JButton("Next") ;
		next.addActionListener(this) ;
		background.add(next) ;
	}

	public void actionPerformed(ActionEvent ae)
	{
		JButton n = (JButton) ae.getSource() ;
		if ( n == next )
		{
			close_frame() ;
			Save_To_Highscores ob = new Save_To_Highscores(m1,s1,mil1) ;
		}
	}
}

// This class displays the highscore in tabular column 
class Highscore extends JFrame implements ActionListener{  //<< Persistent >>
    
    JButton back ;
    JLabel background ;
    TextArea field ;
    
    Highscore()
    {
      change_path() ;
    }
    
    public void close_frame()
    {
        setVisible(false) ;
    }
            
    
    public void change_path()
    {
        Highscore ob = new Highscore(1) ;
        ob.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE) ;
        ob.setLocationRelativeTo(null) ;
        ob.setVisible(true) ;
    }
    
    public Highscore(int i)
    { 
        super("Highscore") ;
        int a = 0 , j = 0 ;
        
        setLayout(new BorderLayout()) ;
        background = new JLabel(new ImageIcon(getClass().getResource("/images/black_white.jpg"))) ;
        add(background) ;
        background.setLayout(new FlowLayout()) ;
        
        String[] colHeads = { "Name", "Timing" } ;
        Object[][] data = new Object[10][2] ;
        
        setSize(500,500) ;
        
        back = new JButton("          Back           ") ;
        back.addActionListener(this) ;
        
        try{
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/dodge_me","root","forgotpass1") ;
            
            Statement stm = con.createStatement() ;
            
            ResultSet rs = stm.executeQuery("select * from highscore order by Time desc limit 10") ;
            
            while(rs.next())
            {
                j = 0;             
                data[a][j++] = rs.getString("Name") ;
                data[a++][j++] = rs.getString("Timing") ;                                       
            }
        }catch(Exception e)
        {
            System.out.println(e) ;
        }
        
        JTable table = new JTable(data, colHeads) ;
        JScrollPane jsp = new JScrollPane(table) ;
        background.add(jsp) ;
        background.add(back) ;   
    }
    
    @Override
    public void actionPerformed(ActionEvent ae)
    {
        JButton b =(JButton)ae.getSource() ;
        
        if( b == back )
        {
            close_frame() ;
            Main_try ob = new Main_try() ;
            ob.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE) ;
            ob.setLocationRelativeTo(null);
            ob.setVisible(true) ;
        }
    }
}
